#pragma once
#include "PLAYER.h"
#include "ARBITRO.h"

class TABLERO
{
public:
    void mostrarJugada(PLAYER j1, PLAYER j2);
    void mostrarGanador(ARBITRO arbitro);
};

