#pragma once
#include "PLAYER.h"
class PLAYERPc : public PLAYER
{
    public:
	void seleccionar();
};

